// config/database.js
module.exports = {

    'url' : 'mongodb+srv://kellycastanos:Castanos1!@cluster0.0jwl8.mongodb.net/logins?retryWrites=true&w=majority', 
    'dbName': 'savage-auth'
};
