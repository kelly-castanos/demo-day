// config/database.js
module.exports = {

    'url' : 'mongodb+srv://demo:demo@cluster0.q2ojb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', 
    'dbName': 'demo'
};
